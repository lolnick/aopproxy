package aopInterface;

public interface Advisor {
	Advice getAdvice();
}
