package aopInterface;

public interface AfterAdvice extends Advice{

}
