package aopInterface;

public interface Advice {

}
