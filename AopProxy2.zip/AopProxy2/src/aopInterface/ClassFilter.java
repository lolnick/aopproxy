package aopInterface;

public interface ClassFilter {
	boolean matches(Class<?> cls);
}
