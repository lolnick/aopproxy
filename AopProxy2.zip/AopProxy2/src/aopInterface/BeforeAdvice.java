package aopInterface;

public interface BeforeAdvice extends Advice {
}
