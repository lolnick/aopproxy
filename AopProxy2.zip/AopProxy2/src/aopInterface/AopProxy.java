package aopInterface;

public interface AopProxy {
	Object getProxy();
}
