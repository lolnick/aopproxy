package aopInterface;

public interface ThrowsAdvice extends AfterAdvice {
}
