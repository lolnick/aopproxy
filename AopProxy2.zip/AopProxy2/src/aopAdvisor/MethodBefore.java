package aopAdvisor;

import java.lang.reflect.Method;

import aopInterface.MethodBeforeAdvice;
import aopInterface.MethodInterceptor;

public class MethodBefore implements MethodInterceptor {

	private MethodBeforeAdvice advice;
	
	public MethodBefore(MethodBeforeAdvice advice)
	{
		this.advice = advice;
	}
	
	@Override
	public Object invoke(Object target, Method method, Object[] args) throws Throwable {
		advice.before(method, args, target);
		return method.invoke(target, args);
	}

}
