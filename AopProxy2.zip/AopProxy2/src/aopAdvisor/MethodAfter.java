package aopAdvisor;

import java.lang.reflect.Method;

import aopInterface.AfterReturningAdvice;
import aopInterface.MethodInterceptor;

public class MethodAfter implements MethodInterceptor {

	private AfterReturningAdvice advice;
	
	public MethodAfter(AfterReturningAdvice advice)
	{
		this.advice = advice;
	}
	
	@Override
	public Object invoke(Object target, Method method, Object[] args) throws Throwable {
		Object returnValue = method.invoke(target, args);
		advice.afterReturning(returnValue, method, args, target);
		return returnValue;
	}

}
