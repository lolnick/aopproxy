package aopAdvisor;

public class Advisor {
	private Object advice;
	private String mappedName;
	public Object getAdvice() {
		return advice;
	}
	public void setAdvice(Object advice) {
		this.advice = advice;
	}
	public String getMappedName() {
		return mappedName;
	}
	public void setMappedName(String mappedName) {
		this.mappedName = mappedName;
	}
	
}
