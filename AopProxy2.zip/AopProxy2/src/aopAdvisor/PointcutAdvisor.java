package aopAdvisor;

import aopInterface.Advisor;
import aopInterface.Pointcut;

public interface PointcutAdvisor extends Advisor {
	Pointcut getPointcut();
}
