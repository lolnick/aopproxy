package aopAdvisor;

import java.lang.reflect.Method;

import aopInterface.MethodMatcher;

public abstract class StaticMethodMatcher implements MethodMatcher {
	public boolean mathces(Method method, Class<?> targetClass, Object... args)
	{
		throw new UnsupportedOperationException("Illegal MethodMatcher usage");
	}
	public boolean isRuntime()
	{
		return false;
	}
}
