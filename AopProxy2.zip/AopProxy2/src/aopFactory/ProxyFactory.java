package aopFactory;

public class ProxyFactory extends AdvisedSupport{
	
	public Object getProxy() {
		return new Aopproxy(this).getProxy();
	}
}
