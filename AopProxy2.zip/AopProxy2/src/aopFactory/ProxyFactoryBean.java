package aopFactory;

import aopInterface.Advice;
import aopAdvisor.Advisor;
import aopAdvisor.NameMatchMethodPointcutAdvisor;
import aopAdvisor.TargetSource;
import bean.PropertyValues;
import factory.BeanFactory;
import factory.XMLBeanFactory;
import resource.LocalFileResource;


public class ProxyFactoryBean implements FactoryBean{
	//�����Ľӿ�
	private String proxyInterfaces;
	//������Ŀ����
	private Object target;
	//advisor
	private String interceptorName;
	
	
	public String getProxyInterfaces() {
		return proxyInterfaces;
	}


	public void setProxyInterfaces(String proxyInterfaces) {
		this.proxyInterfaces = proxyInterfaces;
	}


	public Object getTarget() {
		return target;
	}


	public void setTarget(Object target) {
		this.target = target;
	}


	public String getInterceptorName() {
		return interceptorName;
	}


	public void setInterceptorName(String interceptorName) {
		this.interceptorName = interceptorName;
	}


	@Override
	public Object getObject() {
		// TODO Auto-generated method stub
		LocalFileResource resource = new LocalFileResource("aop.xml");
		BeanFactory beanFactory = new XMLBeanFactory(resource);
		
		TargetSource targetSource = new TargetSource();
		targetSource.setTarget(this.target);
		
		ProxyFactory proxyFactory = new ProxyFactory();
		proxyFactory.setTargetSource(targetSource);
		try {
			proxyFactory.setInterfaces(Class.forName(this.proxyInterfaces));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Advisor ad = (Advisor)beanFactory.getBean(this.interceptorName);
		NameMatchMethodPointcutAdvisor advisor = new NameMatchMethodPointcutAdvisor();
		advisor.setAdvice((Advice)ad.getAdvice());
		advisor.setMappedName(ad.getMappedName());
		proxyFactory.setAdvisor(advisor);
		
		
		return proxyFactory.getProxy();
	}

}
