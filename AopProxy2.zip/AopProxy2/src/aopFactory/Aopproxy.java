package aopFactory;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import aopAdvisor.MethodAfter;
import aopAdvisor.MethodBefore;
import aopAdvisor.PointcutAdvisor;
import aopAdvisor.ThrowsAdviceInterceptor;
import aopInterface.AfterReturningAdvice;
import aopInterface.AopProxy;
import aopInterface.MethodBeforeAdvice;
import aopInterface.MethodInterceptor;
import aopInterface.ThrowsAdvice;

public class Aopproxy implements AopProxy, InvocationHandler{

	private AdvisedSupport advised;
	
	public Aopproxy(AdvisedSupport advised)
	{
		this.advised = advised;
	}
	
	public Object getProxy()
	{
		return Proxy.newProxyInstance(
				this.getClass().getClassLoader(),
				new Class[]{advised.getInterfaces()}, 
				this);
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args)
			throws Throwable {
		
		PointcutAdvisor pointcutAdvisor = (PointcutAdvisor) advised.getAdvisor();
		
		if(pointcutAdvisor.getPointcut().getMethodMatcher().matches(method, advised.getTargetSource().getTarget().getClass()))
		{
			
			if(advised.getAdvisor().getAdvice() instanceof MethodBeforeAdvice)
			{
				MethodBeforeAdvice advice = (MethodBeforeAdvice)advised.getAdvisor().getAdvice();
				MethodInterceptor interceptor = new MethodBefore(advice);
				return interceptor.invoke(advised.getTargetSource().getTarget(), method, args);
			}
			if(advised.getAdvisor().getAdvice() instanceof AfterReturningAdvice)
			{
				AfterReturningAdvice advice = (AfterReturningAdvice)advised.getAdvisor().getAdvice();
				MethodInterceptor interceptor = new MethodAfter(advice);
				return interceptor.invoke(advised.getTargetSource().getTarget(), method, args);
			}
			if(advised.getAdvisor().getAdvice() instanceof ThrowsAdvice)
			{
				ThrowsAdvice advice = (ThrowsAdvice)advised.getAdvisor().getAdvice();
				MethodInterceptor interceptor = new ThrowsAdviceInterceptor(advice);
				return interceptor.invoke(advised.getTargetSource().getTarget(), method, args);
			}
		}
			
		return method.invoke(advised.getTargetSource().getTarget(), args);
	}

}
