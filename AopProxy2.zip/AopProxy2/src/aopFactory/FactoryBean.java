package aopFactory;

public interface FactoryBean {
	Object getObject();
}
