package test;

public interface FooInterface {
	 public void printFoo();
	 public void dummyFoo();
}
