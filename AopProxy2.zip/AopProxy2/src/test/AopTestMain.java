package test;

import aopFactory.*;
import factory.BeanFactory;
import factory.XMLBeanFactory;
import resource.LocalFileResource;

public class AopTestMain {
	public static void main(String[] args) {
        LocalFileResource resource = new LocalFileResource("aop.xml");
		BeanFactory beanFactory = new XMLBeanFactory(resource);
		ProxyFactoryBean proy=(ProxyFactoryBean) beanFactory.getBean("foo");
	    //FooInterface foo = (FooInterface)beanFactory.getBean("foo");
		FooInterface foo=(FooInterface) proy.getObject();
	    foo.printFoo();
	    foo.dummyFoo();
	  }

}
